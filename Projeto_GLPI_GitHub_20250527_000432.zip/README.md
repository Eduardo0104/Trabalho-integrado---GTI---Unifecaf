# Projeto de Modernização de Infraestrutura com GLPI

Este repositório contém a documentação completa do projeto acadêmico de modernização da gestão de ativos utilizando GLPI, tecnologias IoT e biometria.

## Estrutura do Projeto
- Documentação técnica e relatórios
- Scripts e manuais
- Diagramas e imagens
- Apresentação final

## Objetivo
Modernizar a gestão de ativos de TI por meio da implementação do GLPI integrado a sensores IoT e biometria facial, promovendo mais segurança, controle e visibilidade para empresas de transporte.

## Autores
- Aluno 1
- Aluno 2
- Aluno 3


# 7. Referências

- BRASIL. Lei Geral de Proteção de Dados (LGPD). Disponível em: https://www.planalto.gov.br. Acesso em: 10 mar. 2024.
- GLPI Project. Documentação oficial. Disponível em: https://glpi-project.org
- FUSIONINVENTORY. Plugins e documentação. Disponível em: https://wiki.fusioninventory.org


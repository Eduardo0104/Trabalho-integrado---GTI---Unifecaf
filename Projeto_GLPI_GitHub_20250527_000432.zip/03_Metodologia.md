# 3. Metodologia

A metodologia adotada baseou-se em práticas ágeis, com divisão de tarefas entre os integrantes, pesquisa aplicada, simulação de testes e uso de ferramentas como Oracle VirtualBox, GLPI, plugins e sensores simulados.

As etapas incluíram:
- Pesquisa de ferramentas e tecnologias;
- Simulação de ambiente em máquina virtual;
- Configuração do GLPI e plugins;
- Criação de documentação e apresentação.

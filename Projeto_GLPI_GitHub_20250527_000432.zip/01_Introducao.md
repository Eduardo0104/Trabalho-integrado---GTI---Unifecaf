# 1. Introdução

Este projeto tem como foco a modernização da gestão de ativos de TI utilizando o GLPI, incorporando sensores IoT e autenticação por biometria facial. A solução visa atender empresas de transporte, oferecendo maior controle, segurança e automação na gestão dos seus recursos tecnológicos.
